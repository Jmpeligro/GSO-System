<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in
if (!isLoggedIn()) {
    header("Location: ../../template/login.php"); // Updated path
    exit();
}

// CRUD Operations
// ===============

// DELETE operation
if (isset($_POST['delete_equipment']) && isAdmin()) {
    $equipment_id = (int)$_POST['equipment_id'];
    
    // Check if equipment exists and can be deleted (not borrowed)
    $check_sql = "SELECT status FROM equipment WHERE equipment_id = $equipment_id";
    $check_result = $conn->query($check_sql);
    
    if ($check_result->num_rows > 0) {
        $equipment = $check_result->fetch_assoc();
        if ($equipment['status'] == 'borrowed') {
            $_SESSION['error'] = "Cannot delete equipment that is currently borrowed.";
        } else {
            // Delete the equipment
            $delete_sql = "DELETE FROM equipment WHERE equipment_id = $equipment_id";
            if ($conn->query($delete_sql) === TRUE) {
                $_SESSION['success'] = "Equipment deleted successfully!";
            } else {
                $_SESSION['error'] = "Error deleting equipment: " . $conn->error;
            }
        }
    } else {
        $_SESSION['error'] = "Equipment not found.";
    }
    
    // Redirect to refresh the page
    header("Location: equipment.php");
    exit();
}

// UPDATE status quickly
if (isset($_POST['update_status']) && isAdmin()) {
    $equipment_id = (int)$_POST['equipment_id'];
    $new_status = sanitize($_POST['new_status']);
    
    if (empty($new_status)) {
        $_SESSION['error'] = "No status selected.";
        header("Location: equipment.php");
        exit();
    }
    
    $allowed_statuses = ['available', 'maintenance', 'retired'];
    if (in_array($new_status, $allowed_statuses)) {
        $update_sql = "UPDATE equipment SET status = '$new_status' WHERE equipment_id = $equipment_id AND status != 'borrowed'";
        if ($conn->query($update_sql) === TRUE) {
            if ($conn->affected_rows > 0) {
                $_SESSION['success'] = "Equipment status updated to " . ucfirst($new_status);
            } else {
                $_SESSION['error'] = "Unable to update status - equipment may be borrowed.";
            }
        } else {
            $_SESSION['error'] = "Error updating status: " . $conn->error;
        }
    } else {
        $_SESSION['error'] = "Invalid status selected.";
    }
    
    // Redirect to refresh the page
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build the SQL query with filters
$sql = "SELECT e.*, c.name as category_name 
        FROM equipment e
        JOIN categories c ON e.category_id = c.category_id
        WHERE 1=1";

if (!empty($status_filter)) {
    $sql .= " AND e.status = '$status_filter'";
}

if ($category_filter > 0) {
    $sql .= " AND e.category_id = $category_filter";
}

if (!empty($search_query)) {
    // More secure way to handle search
    $search_term = '%' . $search_query . '%';
    $sql .= " AND (e.name LIKE ? OR e.equipment_code LIKE ? OR e.description LIKE ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $search_term, $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql .= " ORDER BY e.name ASC";
    $result = $conn->query($sql);
}

// Get all categories for the filter dropdown
$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($sql_categories);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment Management - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
    <script>
        function confirmDelete(id, name) {
            return confirm('Are you sure you want to delete "' + name + '"? This action cannot be undone.');
        }
        
        // Function to check if dropdown value was changed before submitting
        function validateStatusChange(selectElement) {
            if (selectElement.value === "") {
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }
    </script>
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <div class="page-header">
            <h2>Equipment Management</h2>
            <?php if (isAdmin()): ?>
            <a href="add_equipment.php" class="btn btn-primary">Add New Equipment</a> <!-- Updated path -->
            <?php endif; ?>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']);
            ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php 
                echo $_SESSION['error']; 
                unset($_SESSION['error']);
            ?>
        </div>
        <?php endif; ?>
        
        <div class="filter-section">
            <form method="get" action="equipment.php" class="filter-form">
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">All Statuses</option>
                        <option value="available" <?php echo $status_filter == 'available' ? 'selected' : ''; ?>>Available</option>
                        <option value="borrowed" <?php echo $status_filter == 'borrowed' ? 'selected' : ''; ?>>Borrowed</option>
                        <option value="maintenance" <?php echo $status_filter == 'maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                        <option value="retired" <?php echo $status_filter == 'retired' ? 'selected' : ''; ?>>Retired</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category">
                        <option value="0">All Categories</option>
                        <?php 
                        // Reset the result pointer
                        $categories_result->data_seek(0);
                        while ($category = $categories_result->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $category['category_id']; ?>" <?php echo $category_filter == $category['category_id'] ? 'selected' : ''; ?>>
                            <?php echo $category['name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="search">Search</label>
                    <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search equipment...">
                </div>
                
                <button type="submit" class="btn">Apply Filters</button>
                <a href="equipment.php" class="btn btn-secondary">Reset</a>
            </form>
        </div>
        
        <div class="equipment-list">
            <?php if ($result && $result->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Condition</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['equipment_code']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                            <td><span class="status-badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                            <td><?php echo ucfirst($row['condition_status']); ?></td>
                            <td class="actions">
                                <a href="view_equipment.php?id=<?php echo $row['equipment_id']; ?>" class="btn btn-small">View</a>
                                
                                <?php if (isAdmin()): ?>
                                    <!-- Quick status change dropdown -->
                                    <?php if ($row['status'] != 'borrowed'): ?>
                                    <form method="post" action="equipment.php" style="display:inline-block; margin-right: 5px;" onsubmit="return validateStatusChange(this.new_status)">
                                        <input type="hidden" name="equipment_id" value="<?php echo $row['equipment_id']; ?>">
                                        <select name="new_status" class="status-select" style="padding: 4px; border-radius: 3px;">
                                            <option value="">Change Status</option>
                                            <option value="available" <?php echo $row['status'] == 'available' ? 'disabled' : ''; ?>>Available</option>
                                            <option value="maintenance" <?php echo $row['status'] == 'maintenance' ? 'disabled' : ''; ?>>Maintenance</option>
                                            <option value="retired" <?php echo $row['status'] == 'retired' ? 'disabled' : ''; ?>>Retired</option>
                                        </select>
                                        <input type="hidden" name="update_status" value="1">
                                        <button type="submit" class="btn btn-small">Update</button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <a href="edit_equipment.php?id=<?php echo $row['equipment_id']; ?>" class="btn btn-small btn-secondary">Edit</a>
                                    
                                    <!-- Delete form -->
                                    <?php if ($row['status'] != 'borrowed'): ?>
                                    <form method="post" action="equipment.php" style="display:inline-block;">
                                        <input type="hidden" name="equipment_id" value="<?php echo $row['equipment_id']; ?>">
                                        <input type="hidden" name="delete_equipment" value="1">
                                        <button type="submit" class="btn btn-small btn-danger" 
                                                onclick="return confirmDelete(<?php echo $row['equipment_id']; ?>, '<?php echo htmlspecialchars(addslashes($row['name']), ENT_QUOTES); ?>')">
                                            Delete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <?php if ($row['status'] == 'available'): ?>
                                <a href="borrow_equipment.php?id=<?php echo $row['equipment_id']; ?>" class="btn btn-small btn-primary">Borrow</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <p>No equipment found with the current filters.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
</body>
</html>