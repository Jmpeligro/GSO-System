<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in and is admin
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../templates/login.php"); // Updated path
    exit();
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Category ID is required.";
    header("Location: categories.php"); // Updated path
    exit();
}

$category_id = (int)$_GET['id'];

// Get category data
$sql = "SELECT * FROM categories WHERE category_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Category not found.";
    header("Location: categories.php"); // Updated path
    exit();
}

$category = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $description = sanitize($_POST['description']);
    
    if (empty($name)) {
        $_SESSION['error'] = "Category name is required.";
    } else {
        // Check if another category with the same name exists
        $check_sql = "SELECT COUNT(*) as count FROM categories WHERE name = ? AND category_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $name, $category_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $existing_count = $check_result->fetch_assoc()['count'];
        
        if ($existing_count > 0) {
            $_SESSION['error'] = "Another category with this name already exists.";
        } else {
            // Update category
            $update_sql = "UPDATE categories SET name = ?, description = ? WHERE category_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssi", $name, $description, $category_id);
            
            if ($update_stmt->execute()) {
                $_SESSION['success'] = "Category updated successfully.";
                header("Location: categories.php"); // Updated path
                exit();
            } else {
                $_SESSION['error'] = "Error updating category.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <div class="page-header">
            <h2>Edit Category</h2>
            <a href="categories.php" class="btn btn-secondary">Back to Categories</a> <!-- Updated path -->
        </div>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="post" action="edit_categories.php?id=<?php echo $category_id; ?>"> <!-- Updated path -->
                <div class="form-group">
                    <label for="name">Category Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($category['description']); ?></textarea>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn btn-primary">Update Category</button>
                    <a href="categories.php" class="btn btn-secondary">Cancel</a> <!-- Updated path -->
                </div>
            </form>
        </div>
        
        <!-- Equipment in this category -->
        <div class="category-equipment">
            <h3>Equipment in this Category</h3>
            <?php
            // Get equipment in this category
            $equipment_sql = "SELECT * FROM equipment WHERE category_id = ? ORDER BY name ASC";
            $equipment_stmt = $conn->prepare($equipment_sql);
            $equipment_stmt->bind_param("i", $category_id);
            $equipment_stmt->execute();
            $equipment_result = $equipment_stmt->get_result();
            
            if ($equipment_result->num_rows > 0):
            ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Condition</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $equipment_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['equipment_code']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><span class="status-badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                            <td><?php echo ucfirst($row['condition_status']); ?></td>
                            <td>
                                <a href="../equipment/view_equipment.php?id=<?php echo $row['equipment_id']; ?>" class="btn btn-small">View</a> <!-- Updated path -->
                                <a href="../equipment/edit_equipment.php?id=<?php echo $row['equipment_id']; ?>" class="btn btn-small btn-secondary">Edit</a> <!-- Updated path -->
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <p>No equipment in this category.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
</body>
</html>