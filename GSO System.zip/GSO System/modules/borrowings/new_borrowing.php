<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in and is admin
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../templates/login.php"); // Updated path
    exit();
}

// Get all available equipment
$sql_equipment = "SELECT equipment_id, name, equipment_code FROM equipment 
                 WHERE status = 'available'
                 ORDER BY name";
$result_equipment = $conn->query($sql_equipment);

// Get all users
$sql_users = "SELECT user_id, first_name, last_name, email FROM users ORDER BY last_name, first_name";
$result_users = $conn->query($sql_users);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_id = (int)$_POST['equipment_id'];
    $user_id = (int)$_POST['user_id'];
    $borrow_date = sanitize($_POST['borrow_date']);
    $due_date = sanitize($_POST['due_date']);
    $notes = sanitize($_POST['notes']);
    
    // Validate data
    $errors = [];
    
    if ($equipment_id <= 0) {
        $errors[] = "Please select valid equipment.";
    }
    
    if ($user_id <= 0) {
        $errors[] = "Please select a valid user.";
    }
    
    $borrow_datetime = new DateTime($borrow_date);
    $due_datetime = new DateTime($due_date);
    
    if ($due_datetime <= $borrow_datetime) {
        $errors[] = "Due date must be after the borrow date.";
    }
    
    // Verify equipment is available
    $check_equipment = "SELECT status FROM equipment WHERE equipment_id = ?";
    $stmt = $conn->prepare($check_equipment);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $equipment_result = $stmt->get_result();
    
    if ($equipment_result->num_rows == 0) {
        $errors[] = "Equipment not found.";
    } else {
        $equipment_status = $equipment_result->fetch_assoc()['status'];
        if ($equipment_status !== 'available') {
            $errors[] = "Selected equipment is not available for borrowing.";
        }
    }
    
    // If no errors, process the borrowing
    if (empty($errors)) {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert borrowing record
            $insert_borrowing = "INSERT INTO borrowings 
                                (equipment_id, user_id, borrow_date, due_date, status, notes, 
                                 approval_status, admin_issued_id)
                                VALUES (?, ?, ?, ?, 'active', ?, 'approved', ?)";
            $stmt = $conn->prepare($insert_borrowing);
            $stmt->bind_param("iisssi", $equipment_id, $user_id, $borrow_date, $due_date, $notes, $_SESSION['user_id']);
            $stmt->execute();
            
            // Update equipment status
            $update_equipment = "UPDATE equipment SET status = 'borrowed', updated_at = NOW() 
                                WHERE equipment_id = ?";
            $stmt = $conn->prepare($update_equipment);
            $stmt->bind_param("i", $equipment_id);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            $_SESSION['success'] = "Equipment borrowed successfully.";
            header("Location: borrowings.php"); // Updated path
            exit();
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            $errors[] = "Error processing borrowing: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Borrowing - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <div class="page-header">
            <h2>Create New Borrowing</h2>
            <div class="action-buttons">
                <a href="borrowings.php" class="btn btn-secondary">Back to Borrowings</a> <!-- Updated path -->
            </div>
        </div>
        
        <?php if (isset($errors) && !empty($errors)): ?>
            <div class="error-message">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="borrowing-form">
            <div class="form-group">
                <label for="equipment_id">Equipment</label>
                <select id="equipment_id" name="equipment_id" required>
                    <option value="">Select Equipment</option>
                    <?php while ($equipment = $result_equipment->fetch_assoc()): ?>
                        <option value="<?php echo $equipment['equipment_id']; ?>">
                            <?php echo $equipment['name'] . ' (' . $equipment['equipment_code'] . ')'; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="user_id">Borrower</label>
                <select id="user_id" name="user_id" required>
                    <option value="">Select User</option>
                    <?php while ($user = $result_users->fetch_assoc()): ?>
                        <option value="<?php echo $user['user_id']; ?>">
                            <?php echo $user['first_name'] . ' ' . $user['last_name'] . ' (' . $user['email'] . ')'; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-row">
                <div class="form-group half">
                    <label for="borrow_date">Borrow Date</label>
                    <input type="datetime-local" id="borrow_date" name="borrow_date" required>
                </div>
                
                <div class="form-group half">
                    <label for="due_date">Due Date</label>
                    <input type="datetime-local" id="due_date" name="due_date" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="notes">Notes/Purpose</label>
                <textarea id="notes" name="notes" rows="3" placeholder="Why is this equipment being borrowed?"></textarea>
            </div>
            
            <div class="form-buttons">
                <button type="submit" class="btn btn-primary">Create Borrowing</button>
                <a href="borrowings.php" class="btn btn-secondary">Cancel</a> <!-- Updated path -->
            </div>
        </form>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Set default dates
        const now = new Date();
        const nextWeek = new Date();
        nextWeek.setDate(now.getDate() + 7); // Default to 7 days borrowing period
        
        // Format dates for datetime-local input
        const formatDate = (date) => {
            return date.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:MM
        };
        
        document.getElementById('borrow_date').value = formatDate(now);
        document.getElementById('due_date').value = formatDate(nextWeek);
    });
    </script>
</body>
</html>