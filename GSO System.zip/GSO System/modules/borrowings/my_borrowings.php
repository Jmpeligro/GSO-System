<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in
if (!isLoggedIn()) {
    header("Location: ../../templates/login.php"); // Updated path
    exit();
}

// Get user's borrowings
$user_id = $_SESSION['user_id'];
$sql = "SELECT b.*, e.name as equipment_name, e.equipment_code 
        FROM borrowings b
        JOIN equipment e ON b.equipment_id = e.equipment_id
        WHERE b.user_id = ?
        ORDER BY b.borrow_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Handle cancellation of pending requests
if (isset($_GET['cancel']) && !empty($_GET['cancel'])) {
    $borrowing_id = (int)$_GET['cancel'];
    
    // Verify that this borrowing belongs to the current user and is still pending
    $check_sql = "SELECT * FROM borrowings WHERE borrowing_id = ? AND user_id = ? AND approval_status = 'pending'";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $borrowing_id, $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        // Delete the pending request
        $delete_sql = "DELETE FROM borrowings WHERE borrowing_id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $borrowing_id);
        
        if ($delete_stmt->execute()) {
            $_SESSION['success'] = "Borrowing request cancelled successfully.";
        } else {
            $_SESSION['error'] = "Error cancelling request.";
        }
    } else {
        $_SESSION['error'] = "Invalid request or request already processed.";
    }
    
    header("Location: my_borrowings.php"); // Updated path
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Borrowings - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <h2>My Borrowings</h2>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success-message"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <div class="borrowings-list">
            <?php if ($result->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Equipment</th>
                            <th>Code</th>
                            <th>Borrow Date</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Approval Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): 
                            $is_overdue = ($row['status'] == 'active' && strtotime($row['due_date']) < time());
                            $status_class = $is_overdue ? 'overdue' : $row['status'];
                        ?>
                        <tr>
                            <td><?php echo $row['equipment_name']; ?></td>
                            <td><?php echo $row['equipment_code']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['borrow_date'])); ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['due_date'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $status_class; ?>">
                                    <?php echo $is_overdue ? 'Overdue' : ucfirst($row['status']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $row['approval_status']; ?>">
                                    <?php echo ucfirst($row['approval_status']); ?>
                                </span>
                            </td>
                            <td class="actions">
                                <a href="view_borrowing.php?id=<?php echo $row['borrowing_id']; ?>" class="btn btn-small">View</a> <!-- Updated path -->
                                
                                <?php if ($row['approval_status'] == 'pending'): ?>
                                <a href="my_borrowings.php?cancel=<?php echo $row['borrowing_id']; ?>" 
                                   class="btn btn-small btn-danger"
                                   onclick="return confirm('Are you sure you want to cancel this request?')">Cancel</a>
                                <?php endif; ?>
                                
                                <?php if ($row['status'] == 'active' && $row['approval_status'] == 'approved'): ?>
                                <a href="return_borrowing.php?id=<?php echo $row['borrowing_id']; ?>" 
                                   class="btn btn-small btn-primary"
                                   onclick="return confirm('Are you sure you want to mark this equipment as returned?')">Return</a> <!-- Updated path -->
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <p>You have no borrowing records at this time.</p>
                    <a href="../equipment/equipment.php" class="btn btn-primary">Browse Equipment</a> <!-- Updated path -->
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
</body>
</html>