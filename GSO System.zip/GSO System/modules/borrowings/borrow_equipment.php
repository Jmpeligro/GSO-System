<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in
if (!isLoggedIn()) {
    header("Location: ../../templates/login.php"); // Updated path
    exit();
}

// Check if equipment ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../equipment/equipment.php"); // Updated path
    exit();
}

$equipment_id = (int)$_GET['id'];

// Get equipment details
$sql = "SELECT e.*, c.name as category_name FROM equipment e
        JOIN categories c ON e.category_id = c.category_id
        WHERE e.equipment_id = ? AND e.status = 'available'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $equipment_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if equipment exists and is available
if ($result->num_rows == 0) {
    $_SESSION['error'] = "Equipment not found or not available for borrowing.";
    header("Location: ../equipment/equipment.php"); // Updated path
    exit();
}

$equipment = $result->fetch_assoc();

// Process form submission
$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $borrow_date = sanitize($_POST['borrow_date']);
    $due_date = sanitize($_POST['due_date']);
    $purpose = sanitize($_POST['purpose']);
    
    // Validate dates
    $borrow_datetime = new DateTime($borrow_date);
    $due_datetime = new DateTime($due_date);
    $now = new DateTime();
    
    if ($borrow_datetime > $due_datetime) {
        $error = "Due date must be after the borrow date.";
    } else {
        // Get user ID from session
        $user_id = $_SESSION['user_id'];
        
        // Insert borrowing request record with pending approval status
        $sql = "INSERT INTO borrowings (equipment_id, user_id, borrow_date, due_date, status, notes, approval_status)
                VALUES (?, ?, ?, ?, 'pending', ?, 'pending')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iisss", $equipment_id, $user_id, $borrow_date, $due_date, $purpose);
        
        if ($stmt->execute()) {
            // The equipment remains available until approved
            $success = "Equipment borrow request submitted successfully. An administrator will review your request shortly.";
            
            // Wait for a second to ensure the user sees the success message
            header("refresh:2;url=../../modules/borrowings/my_borrowings.php"); // Updated path
        } else {
            $error = "Error processing your request. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Equipment - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <h2>Request to Borrow Equipment</h2>
        
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="success-message"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="equipment-details">
            <h3><?php echo $equipment['name']; ?></h3>
            <div class="details-row">
                <span class="label">Equipment Code:</span>
                <span class="value"><?php echo $equipment['equipment_code']; ?></span>
            </div>
            <div class="details-row">
                <span class="label">Category:</span>
                <span class="value"><?php echo $equipment['category_name']; ?></span>
            </div>
            <div class="details-row">
                <span class="label">Condition:</span>
                <span class="value"><?php echo ucfirst($equipment['condition_status']); ?></span>
            </div>
            <?php if (!empty($equipment['description'])): ?>
                <div class="details-row">
                    <span class="label">Description:</span>
                    <span class="value"><?php echo $equipment['description']; ?></span>
                </div>
            <?php endif; ?>
        </div>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $equipment_id); ?>" class="borrow-form">
            <div class="form-group">
                <label for="borrow_date">Borrow Date</label>
                <input type="datetime-local" id="borrow_date" name="borrow_date" required
                    min="<?php echo date('Y-m-d\TH:i'); ?>">
            </div>
            
            <div class="form-group">
                <label for="due_date">Return Due Date</label>
                <input type="datetime-local" id="due_date" name="due_date" required
                    min="<?php echo date('Y-m-d\TH:i', strtotime('+1 hour')); ?>">
            </div>
            
            <div class="form-group">
                <label for="purpose">Purpose</label>
                <textarea id="purpose" name="purpose" rows="3" required placeholder="Please describe why you need this equipment"></textarea>
            </div>
            
            <div class="form-group agreement">
                <input type="checkbox" id="agreement" name="agreement" required>
                <label for="agreement">I agree to return the equipment in the same condition by the due date. I understand that I am responsible for any damage or loss.</label>
            </div>
            
            <div class="form-buttons">
                <button type="submit" class="btn btn-primary">Submit Borrowing Request</button>
                <a href="../equipment/equipment.php" class="btn btn-secondary">Cancel</a> <!-- Updated path -->
            </div>
        </form>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Set default dates
        const now = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(now.getDate() + 7); // Default to 7 days borrowing period
        
        // Format dates for datetime-local input
        const formatDate = (date) => {
            return date.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:MM
        };
        
        document.getElementById('borrow_date').value = formatDate(now);
        document.getElementById('due_date').value = formatDate(tomorrow);
    });
    </script>
</body>
</html>