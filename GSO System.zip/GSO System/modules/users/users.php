<?php
session_start();
require_once '../../includes/db_connection.php'; // Updated path

// Check if user is logged in and is admin
if (!isLoggedIn() || !isAdmin()) {
    header("Location: ../../templates/login.php"); // Updated path
    exit();
}

// Get filter parameters
$role_filter = isset($_GET['role']) ? sanitize($_GET['role']) : '';
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build the SQL query with filters
$sql = "SELECT * FROM users WHERE 1=1";

if (!empty($role_filter)) {
    $sql .= " AND role = '$role_filter'";
}

if (!empty($search_query)) {
    $sql .= " AND (first_name LIKE '%$search_query%' OR last_name LIKE '%$search_query%' OR email LIKE '%$search_query%' OR department LIKE '%$search_query%')";
}

$sql .= " ORDER BY last_name ASC, first_name ASC";

$result = $conn->query($sql);

// Process delete user if requested
if (isset($_GET['delete']) && isAdmin()) {
    $delete_id = (int)$_GET['delete'];
    
    // Don't allow deleting yourself
    if ($delete_id != $_SESSION['user_id']) {
        // Check if user has active borrowings
        $check_sql = "SELECT COUNT(*) as count FROM borrowings WHERE user_id = ? AND status = 'active'";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $delete_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $active_count = $check_result->fetch_assoc()['count'];
        
        if ($active_count == 0) {
            // Safe to delete the user
            $delete_sql = "DELETE FROM users WHERE user_id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $delete_id);
            
            if ($delete_stmt->execute()) {
                $_SESSION['success'] = "User deleted successfully.";
            } else {
                $_SESSION['error'] = "Error deleting user.";
            }
        } else {
            $_SESSION['error'] = "Cannot delete user with active borrowings.";
        }
    } else {
        $_SESSION['error'] = "You cannot delete your own account.";
    }
    
    // Redirect to refresh the page
    header("Location: users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - University GSO</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Updated path -->
</head>
<body>
    <?php include '../../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <div class="page-header">
            <h2>User Management</h2>
            <a href="add_user.php" class="btn btn-primary">Add New User</a>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success-message"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <div class="filter-section">
            <form method="get" action="users.php" class="filter-form">
                <div class="form-group">
                    <label for="role">Role</label>
                    <select id="role" name="role">
                        <option value="">All Roles</option>
                        <option value="student" <?php echo $role_filter == 'student' ? 'selected' : ''; ?>>Student</option>
                        <option value="faculty" <?php echo $role_filter == 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                        <option value="staff" <?php echo $role_filter == 'staff' ? 'selected' : ''; ?>>Staff</option>
                        <option value="admin" <?php echo $role_filter == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="search">Search</label>
                    <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search users...">
                </div>
                
                <button type="submit" class="btn">Apply Filters</button>
                <a href="users.php" class="btn btn-secondary">Reset</a>
            </form>
        </div>
        
        <div class="user-list">
            <?php if ($result->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['user_id']; ?></td>
                            <td><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo ucfirst($row['role']); ?></td>
                            <td><?php echo $row['department']; ?></td>
                            <td class="actions">
                                <a href="view_user.php?id=<?php echo $row['user_id']; ?>" class="btn btn-small">View</a>
                                <a href="edit_user.php?id=<?php echo $row['user_id']; ?>" class="btn btn-small btn-secondary">Edit</a>
                                <?php if ($row['user_id'] != $_SESSION['user_id']): ?>
                                <a href="users.php?delete=<?php echo $row['user_id']; ?>" class="btn btn-small btn-danger" 
                                   onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-results">
                    <p>No users found with the current filters.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../../includes/footer.php'; ?> <!-- Updated path -->
</body>
</html>