<?php
// Database connection configuration
$servername = getenv('DB_SERVER') ?: 'localhost';
$username = getenv('DB_USERNAME') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';
$dbname = getenv('DB_NAME') ?: 'general_service_office';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    die("Database connection failed. Please try again later.");
}

// Function to sanitize input data for SQL queries
function sanitize($data) {
    global $conn;
    $data = trim($data);
    $data = $conn->real_escape_string($data); // For SQL inputs
    return $data;
}

// Function to sanitize data for HTML output
function sanitizeHTML($data) {
    return htmlspecialchars($data); // For HTML output
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Function to check if user is admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'admin';
}

// Close the database connection when the script ends
register_shutdown_function(function() use ($conn) {
    if ($conn) {
        $conn->close();
    }
});