<?php
// This file contains the header component that will be included in all pages
?>
<header class="header">
    <div class="header-container">
        <div class="logo">
            <a href="../index.php">PLP GSO Management</a> <!-- Updated path -->
        </div>
        
        <nav class="nav-menu">
            <a href="../templates/dashboard.php">Dashboard</a> <!-- Updated path -->
            <a href="../modules/equipment/equipment.php">Equipment</a> <!-- Updated path -->
            <a href="../modules/borrowings/borrowings.php">Borrowings</a> <!-- Updated path -->
            <?php if (isAdmin()): ?>
            <a href="../modules/categories/categories.php">Categories</a> <!-- Updated path -->
            <a href="../modules/users/users.php">Users</a> <!-- Updated path -->
            <a href="../templates/reports.php">Reports</a> <!-- Updated path -->
            <?php endif; ?>
        </nav>
        
        <div class="user-menu">
            <button class="user-menu-button" id="userMenuButton">
                <span><?php echo $_SESSION['name']; ?></span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="user-menu-dropdown" id="userMenuDropdown">
                <a href="../templates/profile.php">My Profile</a> <!-- Updated path -->
                <?php if (!isAdmin()): ?>   
                    <a href="../modules/borrowings/my_borrowings.php">My Borrowings</a> <!-- Updated path -->
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="../templates/settings.php">System Settings</a> <!-- Updated path -->
                <?php endif; ?>
                <a href="../templates/logout.php">Logout</a> <!-- Updated path -->
            </div>
        </div>
    </div>
</header>

<script>
// Toggle user menu dropdown
document.addEventListener('DOMContentLoaded', function() {
    const userMenuButton = document.getElementById('userMenuButton');
    const userMenuDropdown = document.getElementById('userMenuDropdown');
    
    userMenuButton.addEventListener('click', function() {
        userMenuDropdown.classList.toggle('active');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!userMenuButton.contains(event.target) && !userMenuDropdown.contains(event.target)) {
            userMenuDropdown.classList.remove('active');
        }
    });
});
</script>