<?php
// This file contains the footer component that will be included in all pages
?>
<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> University General Service Office Management System</p>
    </div>
</footer>