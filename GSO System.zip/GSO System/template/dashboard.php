<?php
session_start();
require_once '../includes/db_connection.php'; // Updated path

// Check if user is logged in
if (!isLoggedIn()) {
    header("Location: login.php"); // Updated path
    exit();
}

// Get equipment counts
$sql_available = "SELECT COUNT(*) as count FROM equipment WHERE status = 'available'";
$sql_borrowed = "SELECT COUNT(*) as count FROM equipment WHERE status = 'borrowed'";
$sql_maintenance = "SELECT COUNT(*) as count FROM equipment WHERE status = 'maintenance'";
$sql_categories = "SELECT COUNT(*) as count FROM categories";

$result_available = $conn->query($sql_available);
$result_borrowed = $conn->query($sql_borrowed);
$result_maintenance = $conn->query($sql_maintenance);
$result_categories = $conn->query($sql_categories);

if (!$result_available || !$result_borrowed || !$result_maintenance || !$result_categories) {
    error_log("Error fetching equipment counts: " . $conn->error);
    die("Error fetching data. Please try again later.");
}

$available_count = $result_available->fetch_assoc()['count'];
$borrowed_count = $result_borrowed->fetch_assoc()['count'];
$maintenance_count = $result_maintenance->fetch_assoc()['count'];
$categories_count = $result_categories->fetch_assoc()['count'];

// Get recent borrowings
$sql_recent = "SELECT b.borrowing_id, e.name as equipment_name, u.first_name, u.last_name, 
               b.borrow_date, b.due_date, b.status 
               FROM borrowings b
               JOIN equipment e ON b.equipment_id = e.equipment_id
               JOIN users u ON b.user_id = u.user_id
               ORDER BY b.borrow_date DESC LIMIT 5";
$result_recent = $conn->query($sql_recent);

if (!$result_recent) {
    error_log("Error fetching recent borrowings: " . $conn->error);
    die("Error fetching data. Please try again later.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - University GSO Management</title>
    <link rel="stylesheet" href="../assets/css/styles.css"> <!-- Updated path -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <h2>Dashboard</h2>
        
        <!-- Equipment Statistics -->
        <div class="stats-container">
            <div class="stat-box">
                <h3>Available Equipment</h3>
                <div class="stat-number"><?php echo $available_count; ?></div>
                <a href="../modules/equipment/equipment.php?status=available" class="stat-link">View all</a> <!-- Updated path -->
            </div>
            
            <div class="stat-box">
                <h3>Currently Borrowed</h3>
                <div class="stat-number"><?php echo $borrowed_count; ?></div>
                <a href="../modules/equipment/equipment.php?status=borrowed" class="stat-link">View all</a> <!-- Updated path -->
            </div>
            
            <div class="stat-box">
                <h3>Under Maintenance</h3>
                <div class="stat-number"><?php echo $maintenance_count; ?></div>
                <a href="../modules/equipment/equipment.php?status=maintenance" class="stat-link">View all</a> <!-- Updated path -->
            </div>
            
            <div class="stat-box">
                <h3>Equipment Categories</h3>
                <div class="stat-number"><?php echo $categories_count; ?></div>
                <a href="../modules/categories/categories.php" class="stat-link">View all</a> <!-- Updated path -->
            </div>
        </div>
        
        <!-- Equipment Status Chart -->
        <div class="charts-container">
            <div class="chart-box">
                <h3>Equipment Status</h3>
                <canvas id="equipmentStatusChart"></canvas>
            </div>
        </div>
        
        <!-- Recent Borrowings -->
        <div class="recent-section">
            <h3>Recent Borrowings</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Equipment</th>
                        <th>Borrower</th>
                        <th>Borrow Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result_recent->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['borrowing_id']; ?></td>
                        <td><?php echo $row['equipment_name']; ?></td>
                        <td><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></td>
                        <td><?php echo date('M d, Y', strtotime($row['borrow_date'])); ?></td>
                        <td><?php echo date('M d, Y', strtotime($row['due_date'])); ?></td>
                        <td><span class="status-badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                        <td>
                            <a href="../modules/borrowings/view_borrowing.php?id=<?php echo $row['borrowing_id']; ?>" class="btn btn-small">View</a> <!-- Updated path -->
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <a href="../modules/borrowings/borrowings.php" class="view-all-link">View all borrowings</a> <!-- Updated path -->
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?> <!-- Updated path -->
    
    <script>
    // Equipment status chart
    const ctx = document.getElementById('equipmentStatusChart').getContext('2d');
    const equipmentStatusChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Available', 'Borrowed', 'Maintenance'],
            datasets: [{
                data: [<?php echo $available_count; ?>, <?php echo $borrowed_count; ?>, <?php echo $maintenance_count; ?>],
                backgroundColor: ['#4CAF50', '#2196F3', '#FF9800'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
    </script>
</body>
</html>