<?php
session_start();
require_once '../includes/db_connection.php'; // Updated path

// Check if user is logged in and is admin
if (!isLoggedIn() || !isAdmin()) {
    header("Location: login.php"); // Updated path
    exit();
}

// Get filter parameters
$report_type = isset($_GET['report_type']) ? sanitize($_GET['report_type']) : 'equipment_status';
$start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : date('Y-m-d');
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

// Get all categories for filter
$categories_sql = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = $conn->query($categories_sql);

if (!$categories_result) {
    error_log("Error fetching categories: " . $conn->error);
    die("Error fetching data. Please try again later.");
}

// Generate the report
$report_data = [];
$chart_data = [];

switch ($report_type) {
    case 'equipment_status':
        $sql = "SELECT status, COUNT(*) as count FROM equipment GROUP BY status ORDER BY count DESC";
        $result = $conn->query($sql);

        if (!$result) {
            error_log("Error fetching equipment status: " . $conn->error);
            die("Error fetching data. Please try again later.");
        }

        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
            $chart_data[] = [
                'label' => ucfirst($row['status']),
                'value' => $row['count'],
                'color' => getColorForStatus($row['status'])
            ];
        }
        break;

    case 'borrowing_activity':
        $sql = "SELECT DATE(borrow_date) as date, COUNT(*) as count 
                FROM borrowings 
                WHERE borrow_date BETWEEN ? AND ? 
                GROUP BY DATE(borrow_date) 
                ORDER BY date ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $start_date, $end_date);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            error_log("Error fetching borrowing activity: " . $conn->error);
            die("Error fetching data. Please try again later.");
        }

        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
            $chart_data[] = [
                'date' => date('M d', strtotime($row['date'])),
                'count' => $row['count']
            ];
        }
        break;

    case 'overdue_items':
        $sql = "SELECT b.borrowing_id, e.name as equipment_name, e.equipment_code, 
                u.first_name, u.last_name, u.email, 
                b.borrow_date, b.due_date, 
                DATEDIFF(NOW(), b.due_date) as days_overdue
                FROM borrowings b
                JOIN equipment e ON b.equipment_id = e.equipment_id
                JOIN users u ON b.user_id = u.user_id
                WHERE b.status = 'active' AND b.due_date < NOW()
                ORDER BY days_overdue DESC";
        $result = $conn->query($sql);

        if (!$result) {
            error_log("Error fetching overdue items: " . $conn->error);
            die("Error fetching data. Please try again later.");
        }

        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
        }
        break;

    case 'popular_equipment':
        $sql = "SELECT e.equipment_id, e.name, c.name as category_name, 
                COUNT(b.borrowing_id) as borrow_count
                FROM equipment e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN borrowings b ON e.equipment_id = b.equipment_id";

        if ($category_id > 0) {
            $sql .= " WHERE e.category_id = ?";
        }

        $sql .= " GROUP BY e.equipment_id
                ORDER BY borrow_count DESC
                LIMIT 20";

        $stmt = $conn->prepare($sql);
        if ($category_id > 0) {
            $stmt->bind_param("i", $category_id);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            error_log("Error fetching popular equipment: " . $conn->error);
            die("Error fetching data. Please try again later.");
        }

        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
            if (count($chart_data) < 10) {
                $chart_data[] = [
                    'name' => $row['name'],
                    'count' => (int)$row['borrow_count']
                ];
            }
        }
        break;

    case 'user_activity':
        $sql = "SELECT u.user_id, u.first_name, u.last_name, u.email, u.role,
                COUNT(b.borrowing_id) as borrow_count
                FROM users u
                LEFT JOIN borrowings b ON u.user_id = b.user_id
                GROUP BY u.user_id
                ORDER BY borrow_count DESC
                LIMIT 20";
        $result = $conn->query($sql);

        if (!$result) {
            error_log("Error fetching user activity: " . $conn->error);
            die("Error fetching data. Please try again later.");
        }

        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
            if (count($chart_data) < 10) {
                $chart_data[] = [
                    'name' => $row['first_name'] . ' ' . $row['last_name'],
                    'count' => (int)$row['borrow_count']
                ];
            }
        }
        break;
}

// Helper function to get color for status
function getColorForStatus($status) {
    switch ($status) {
        case 'available': return '#27ae60';
        case 'borrowed': return '#3498db';
        case 'maintenance': return '#f39c12';
        case 'retired': return '#e74c3c';
        default: return '#95a5a6';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - University GSO</title>
    <link rel="stylesheet" href="../assets/css/styles.css"> <!-- Updated path -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?> <!-- Updated path -->
    
    <div class="container">
        <div class="page-header">
            <h2>Reports</h2>
            <button id="printReport" class="btn btn-primary">Print Report</button>
        </div>
        
        <div class="filter-section">
            <form method="get" action="reports.php" class="filter-form">
                <div class="form-group">
                    <label for="report_type">Report Type</label>
                    <select id="report_type" name="report_type" onchange="toggleDateFilter()">
                        <option value="equipment_status" <?php echo $report_type == 'equipment_status' ? 'selected' : ''; ?>>Equipment Status</option>
                        <option value="borrowing_activity" <?php echo $report_type == 'borrowing_activity' ? 'selected' : ''; ?>>Borrowing Activity</option>
                        <option value="overdue_items" <?php echo $report_type == 'overdue_items' ? 'selected' : ''; ?>>Overdue Items</option>
                        <option value="popular_equipment" <?php echo $report_type == 'popular_equipment' ? 'selected' : ''; ?>>Popular Equipment</option>
                        <option value="user_activity" <?php echo $report_type == 'user_activity' ? 'selected' : ''; ?>>User Activity</option>
                    </select>
                </div>
                
                <div class="form-group date-filter" <?php echo ($report_type != 'borrowing_activity') ? 'style="display:none;"' : ''; ?>>
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                
                <div class="form-group date-filter" <?php echo ($report_type != 'borrowing_activity') ? 'style="display:none;"' : ''; ?>>
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                
                <div class="form-group category-filter" <?php echo ($report_type != 'popular_equipment') ? 'style="display:none;"' : ''; ?>>
                    <label for="category_id">Category</label>
                    <select id="category_id" name="category_id">
                        <option value="0">All Categories</option>
                        <?php while ($category = $categories_result->fetch_assoc()): ?>
                        <option value="<?php echo $category['category_id']; ?>" <?php echo $category_id == $category['category_id'] ? 'selected' : ''; ?>>
                            <?php echo $category['name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn">Generate Report</button>
            </form>
        </div>
        
        <div class="report-container">
            <h3><?php echo getReportTitle($report_type); ?></h3>
            
            <?php if ($report_type == 'equipment_status' || $report_type == 'borrowing_activity' || 
                      $report_type == 'popular_equipment' || $report_type == 'user_activity'): ?>
                <!-- Chart for visualizing data -->
                <div class="chart-container">
                    <canvas id="reportChart"></canvas>
                </div>
            <?php endif; ?>
            
            <!-- Report data table -->
            <div class="report-data">
                <?php
                switch ($report_type) {
                    case 'equipment_status':
                        displayEquipmentStatusTable($report_data);
                        break;
                    case 'borrowing_activity':
                        displayBorrowingActivityTable($report_data);
                        break;
                    case 'overdue_items':
                        displayOverdueItemsTable($report_data);
                        break;
                    case 'popular_equipment':
                        displayPopularEquipmentTable($report_data);
                        break;
                    case 'user_activity':
                        displayUserActivityTable($report_data);
                        break;
                }
                ?>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?> <!-- Updated path -->
    
    <script>
    // Toggle date filter visibility based on report type
    function toggleDateFilter() {
        const reportType = document.getElementById('report_type').value;
        const dateFilters = document.querySelectorAll('.date-filter');
        const categoryFilter = document.querySelectorAll('.category-filter');
        
        // Toggle date filters
        dateFilters.forEach(filter => {
            filter.style.display = (reportType == 'borrowing_activity') ? 'block' : 'none';
        });
        
        // Toggle category filter
        categoryFilter.forEach(filter => {
            filter.style.display = (reportType == 'popular_equipment') ? 'block' : 'none';
        });
    }
    
    // Print report function
    document.getElementById('printReport').addEventListener('click', function() {
        window.print();
    });
    
    // Create chart based on report type
    document.addEventListener('DOMContentLoaded', function() {
        const reportType = '<?php echo $report_type; ?>';
        const ctx = document.getElementById('reportChart');
        
        <?php if (!empty($chart_data)): ?>
        
        if (reportType === 'equipment_status') {
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($chart_data, 'label')); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_column($chart_data, 'value')); ?>,
                        backgroundColor: <?php echo json_encode(array_column($chart_data, 'color')); ?>,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        title: {
                            display: true,
                            text: 'Equipment Status Distribution'
                        }
                    }
                }
            });
        } else if (reportType === 'borrowing_activity') {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_column($chart_data, 'date')); ?>,
                    datasets: [{
                        label: 'Number of Borrowings',
                        data: <?php echo json_encode(array_column($chart_data, 'count')); ?>,
                        backgroundColor: 'rgba(52, 152, 219, 0.2)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 2,
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Borrowing Activity Over Time'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        } else if (reportType === 'popular_equipment' || reportType === 'user_activity') {
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_column($chart_data, 'name')); ?>,
                    datasets: [{
                        label: 'Number of Borrowings',
                        data: <?php echo json_encode(array_column($chart_data, 'count')); ?>,
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: reportType === 'popular_equipment' ? 'Most Popular Equipment' : 'Most Active Users'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        }
        
        <?php endif; ?>
    });
    </script>
</body>
</html>

<?php
// Helper functions for displaying tables

function getReportTitle($report_type) {
    switch ($report_type) {
        case 'equipment_status': return 'Equipment Status Report';
        case 'borrowing_activity': return 'Borrowing Activity Report';
        case 'overdue_items': return 'Overdue Items Report';
        case 'popular_equipment': return 'Popular Equipment Report';
        case 'user_activity': return 'User Activity Report';
        default: return 'Report';
    }
}

function displayEquipmentStatusTable($data) {
    echo '<table class="data-table">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Count</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>';
    
    $total = array_sum(array_column($data, 'count'));
    
    foreach ($data as $row) {
        $percentage = ($total > 0) ? round(($row['count'] / $total) * 100, 1) : 0;
        echo '<tr>
                <td>' . ucfirst($row['status']) . '</td>
                <td>' . $row['count'] . '</td>
                <td>' . $percentage . '%</td>
              </tr>';
    }
    
    echo '</tbody>
          <tfoot>
            <tr>
                <th>Total</th>
                <th>' . $total . '</th>
                <th>100%</th>
            </tr>
          </tfoot>
        </table>';
}

function displayBorrowingActivityTable($data) {
    echo '<table class="data-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Number of Borrowings</th>
                </tr>
            </thead>
            <tbody>';
    
    foreach ($data as $row) {
        echo '<tr>
                <td>' . date('M d, Y', strtotime($row['date'])) . '</td>
                <td>' . $row['count'] . '</td>
              </tr>';
    }
    
    echo '</tbody>
        </table>';
}

function displayOverdueItemsTable($data) {
    echo '<table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Equipment</th>
                    <th>Code</th>
                    <th>Borrower</th>
                    <th>Email</th>
                    <th>Due Date</th>
                    <th>Days Overdue</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';
    
    foreach ($data as $row) {
        echo '<tr>
                <td>' . $row['borrowing_id'] . '</td>
                <td>' . $row['equipment_name'] . '</td>
                <td>' . $row['equipment_code'] . '</td>
                <td>' . $row['first_name'] . ' ' . $row['last_name'] . '</td>
                <td>' . $row['email'] . '</td>
                <td>' . date('M d, Y', strtotime($row['due_date'])) . '</td>
                <td>' . $row['days_overdue'] . '</td>
                <td>
                    <a href="view_borrowing.php?id=' . $row['borrowing_id'] . '" class="btn btn-small">View</a>
                    <a href="send_reminder.php?id=' . $row['borrowing_id'] . '" class="btn btn-small btn-primary">Send Reminder</a>
                </td>
              </tr>';
    }
    
    echo '</tbody>
        </table>';
}

function displayPopularEquipmentTable($data) {
    echo '<table class="data-table">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Equipment Name</th>
                    <th>Category</th>
                    <th>Number of Borrowings</th>
                </tr>
            </thead>
            <tbody>';
    
    $rank = 1;
    foreach ($data as $row) {
        echo '<tr>
                <td>' . $rank++ . '</td>
                <td>' . $row['name'] . '</td>
                <td>' . $row['category_name'] . '</td>
                <td>' . $row['borrow_count'] . '</td>
              </tr>';
    }
    
    echo '</tbody>
        </table>';
}

function displayUserActivityTable($data) {
    echo '<table class="data-table">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Number of Borrowings</th>
                </tr>
            </thead>
            <tbody>';
    
    $rank = 1;
    foreach ($data as $row) {
        echo '<tr>
                <td>' . $rank++ . '</td>
                <td>' . $row['first_name'] . ' ' . $row['last_name'] . '</td>
                <td>' . $row['email'] . '</td>
                <td>' . ucfirst($row['role']) . '</td>
                <td>' . $row['borrow_count'] . '</td>
              </tr>';
    }
    
    echo '</tbody>
        </table>';
}
?>