<?php
session_start();

// Check if user is logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: template/dashboard.php"); // Updated path
    exit();
} else {
    // Not logged in, redirect to login page
    header("Location: template/login.php"); // Updated path
    exit();
}
?>